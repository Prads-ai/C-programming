//=============================================================
//   Pradsley D'Haiti 
//   CIST2341: C# Programming I
//   Project : Simple Calculator
//   Lab 4 
//=============================================================

namespace SimpleCalculator
{
    public partial class frmCalc : Form
    {
        static double  num1;
        static double num2;
        static double operationResult;
        public frmCalc()
        {
            InitializeComponent();
        }
        // This code change the text color of the form
        private void foreColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog color = new ColorDialog();
            color.ShowHelp = true;
            color.HelpRequest += Color_HelpRequest;
            if (color.ShowDialog() == DialogResult.OK) { 
                lblNum1.ForeColor = color.Color;
                lblNum2.ForeColor = color.Color;
                lblResult.ForeColor = color.Color;
                rdoAddition.ForeColor = color.Color;
                rdoSubstraction.ForeColor = color.Color; 
                rdoMultiplication.ForeColor = color.Color;
                rdoDivision.ForeColor = color.Color;
                gbOperation.ForeColor = color.Color;
            } 
        }
        // This code display a text that help the user understand the choice he/she has to make.
        private void Color_HelpRequest(object? sender, EventArgs e)
        {
            System.Media.SystemSounds.Hand.Play();
            MessageBox.Show("Choose the background color of the text", "Help",MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        // This code allow the user to change the background color of the form
        private void chooseAColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog bgcolor = new ColorDialog();
            if (bgcolor.ShowDialog() == DialogResult.OK) { 
                ActiveForm.BackColor = bgcolor.Color;
            }
        }
       
        private void btnExit_Click(object sender, EventArgs e)
        {
            ExitButton(); 
        }
        // This code display a message before exiting the application
        public static void ExitButton() {
            System.Media.SystemSounds.Hand.Play();
            DialogResult result = MessageBox.Show("Are you sure you want to exit ?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }

        }
        // This code change the text font of the form
        private void changeTextFontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog changeFont = new FontDialog();
            if (changeFont.ShowDialog() == DialogResult.OK) {
                lblNum1.Font = changeFont.Font;
                lblNum2.Font = changeFont.Font;
                lblResult.Font = changeFont.Font;
                gbOperation.Font = changeTextFontToolStripMenuItem.Font;
                
            }
        }

        private void rdoAddition_CheckedChanged(object sender, EventArgs e)
        {
            // Disable all other radio button
            if (rdoAddition.Checked == true) {
                this.Text = rdoAddition.Text;
                btnCalculate.Enabled = true;
                rdoSubstraction.Enabled = false;
                rdoMultiplication.Enabled = false;
                rdoDivision.Enabled = false;
                iptNum1.Focus();
                
            }
        }

        private void rdoSubstraction_CheckedChanged(object sender, EventArgs e)
        {
            // Disable all other radio button
            if (rdoSubstraction.Checked == true) {
                this.Text = rdoSubstraction.Text;
                btnCalculate.Enabled = true;
                rdoAddition.Enabled = false;
                rdoMultiplication.Enabled = false;
                rdoDivision.Enabled = false;
                iptNum1.Focus();
            
            }
        }

        private void rdoMultiplication_CheckedChanged(object sender, EventArgs e)
        {
            // Disable all other radio button
            if (rdoMultiplication.Checked == true) {
                this.Text = rdoMultiplication.Text;
                btnCalculate.Enabled = true;
                rdoAddition.Enabled = false;
                rdoSubstraction.Enabled = false;
                rdoDivision.Enabled = false;
                iptNum1.Focus();
            }
        }

        private void rdoDivision_CheckedChanged(object sender, EventArgs e)
        {
            // Disable all other radio button
            if (rdoDivision.Checked == true) {
                this.Text = rdoDivision.Text;
                btnCalculate.Enabled = true;
                rdoAddition.Enabled = false;
                rdoSubstraction.Enabled = false;
                rdoMultiplication.Enabled = false;
                iptNum1.Focus();
            
            }

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {

            // This code verify that the user does'nt enter a invalid input
            double result1, result2;
            bool tempNum1 = Double.TryParse(iptNum1.Text, out result1);
            bool tempNum2 = Double.TryParse(iptNum2.Text, out result2);

            if (tempNum1 && tempNum2)
            {
                num1 = result1;
                num2 = result2;
                
                if (rdoAddition.Checked == true)
                {
                    operationResult = num1 + num2;
                    iptResult.Text = operationResult.ToString();
                }
                else if (rdoSubstraction.Checked == true)
                {
                    operationResult = num1 - num2;
                    iptResult.Text = operationResult.ToString();
                }
                else if (rdoMultiplication.Checked == true)
                {
                    operationResult = num1 * num2;
                    iptResult.Text = operationResult.ToString();
                }
                // This code Trow an exection if the user divide a number by zero.
                else if (rdoDivision.Checked == true) {
                    try
                    {
                        operationResult = num1 / num2;
                        iptResult.Text = operationResult.ToString();
                    }
                    catch (DivideByZeroException ex1)
                    {
                            
                        System.Media.SystemSounds.Exclamation.Play();
                        MessageBox.Show(ex1.Message,
                            "Invalid Operation", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex1) {

                        System.Media.SystemSounds.Exclamation.Play();
                        MessageBox.Show("An Error has occured",
                            "Unknown Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }// end catch
            }
            else
            {
                System.Media.SystemSounds.Exclamation.Play();
                MessageBox.Show("You have entered a non numeric value, please verify your input",
                    "Non numeric value entered", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
           
            btnCalculate.Visible = true;
            rdoAddition.Enabled = true;
            rdoSubstraction.Enabled = true;
            rdoMultiplication.Enabled = true;
            rdoDivision.Enabled = true;

            iptNum1.Clear();
            iptNum2.Clear();
            iptResult.Clear();
        }

        private async void frmCalc_Load(object sender, EventArgs e)
        {
            await Task.Delay(1000);
            txtChoose.Visible = true;
            await Task.Delay(2000);
            txtChoose.Visible = false;
            
        }

        private void mnuClearBtn_Click(object sender, EventArgs e)
        {
            ClearEverything();
        }

        public void ClearEverything() {
            btnCalculate.Visible = true;
            rdoAddition.Enabled = true;
            rdoSubstraction.Enabled = true;
            rdoMultiplication.Enabled = true;
            rdoDivision.Enabled = true;

            iptNum1.Clear();
            iptNum2.Clear();
            iptResult.Clear();

        }

        private void mnuExitBtn_Click(object sender, EventArgs e)
        {
            // Calling the exit button function
            ExitButton();
        }
    }
}