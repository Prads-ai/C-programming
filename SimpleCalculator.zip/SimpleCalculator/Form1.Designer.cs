﻿namespace SimpleCalculator
{
    partial class frmCalc
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClearBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuExitBtn = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuChosseColorbtn = new System.Windows.Forms.ToolStripMenuItem();
            this.chooseAColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.foreColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changeTextFontToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblNum1 = new System.Windows.Forms.Label();
            this.lblNum2 = new System.Windows.Forms.Label();
            this.iptNum1 = new System.Windows.Forms.TextBox();
            this.iptNum2 = new System.Windows.Forms.TextBox();
            this.gbOperation = new System.Windows.Forms.GroupBox();
            this.txtChoose = new System.Windows.Forms.Label();
            this.rdoDivision = new System.Windows.Forms.RadioButton();
            this.rdoAddition = new System.Windows.Forms.RadioButton();
            this.rdoMultiplication = new System.Windows.Forms.RadioButton();
            this.rdoSubstraction = new System.Windows.Forms.RadioButton();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.lblResult = new System.Windows.Forms.Label();
            this.iptResult = new System.Windows.Forms.TextBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.menuStrip.SuspendLayout();
            this.gbOperation.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.menuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.mnuChosseColorbtn,
            this.helpToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip.Size = new System.Drawing.Size(544, 28);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "Menu";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuClearBtn,
            this.mnuExitBtn});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(46, 24);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // mnuClearBtn
            // 
            this.mnuClearBtn.Name = "mnuClearBtn";
            this.mnuClearBtn.Size = new System.Drawing.Size(224, 26);
            this.mnuClearBtn.Text = "Clear";
            this.mnuClearBtn.Click += new System.EventHandler(this.mnuClearBtn_Click);
            // 
            // mnuExitBtn
            // 
            this.mnuExitBtn.Name = "mnuExitBtn";
            this.mnuExitBtn.Size = new System.Drawing.Size(224, 26);
            this.mnuExitBtn.Text = "Exit";
            this.mnuExitBtn.Click += new System.EventHandler(this.mnuExitBtn_Click);
            // 
            // mnuChosseColorbtn
            // 
            this.mnuChosseColorbtn.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chooseAColorToolStripMenuItem,
            this.foreColorToolStripMenuItem});
            this.mnuChosseColorbtn.Name = "mnuChosseColorbtn";
            this.mnuChosseColorbtn.Size = new System.Drawing.Size(59, 24);
            this.mnuChosseColorbtn.Text = "Color";
            // 
            // chooseAColorToolStripMenuItem
            // 
            this.chooseAColorToolStripMenuItem.Name = "chooseAColorToolStripMenuItem";
            this.chooseAColorToolStripMenuItem.Size = new System.Drawing.Size(159, 26);
            this.chooseAColorToolStripMenuItem.Text = "BG Color";
            this.chooseAColorToolStripMenuItem.Click += new System.EventHandler(this.chooseAColorToolStripMenuItem_Click);
            // 
            // foreColorToolStripMenuItem
            // 
            this.foreColorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.changeTextFontToolStripMenuItem});
            this.foreColorToolStripMenuItem.Name = "foreColorToolStripMenuItem";
            this.foreColorToolStripMenuItem.Size = new System.Drawing.Size(159, 26);
            this.foreColorToolStripMenuItem.Text = "Text Color";
            this.foreColorToolStripMenuItem.Click += new System.EventHandler(this.foreColorToolStripMenuItem_Click);
            // 
            // changeTextFontToolStripMenuItem
            // 
            this.changeTextFontToolStripMenuItem.Name = "changeTextFontToolStripMenuItem";
            this.changeTextFontToolStripMenuItem.Size = new System.Drawing.Size(206, 26);
            this.changeTextFontToolStripMenuItem.Text = "Change Text Font";
            this.changeTextFontToolStripMenuItem.Click += new System.EventHandler(this.changeTextFontToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(55, 24);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(133, 26);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.ToolTipText = "Simple Calculator 1.0";
            // 
            // lblNum1
            // 
            this.lblNum1.AutoSize = true;
            this.lblNum1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblNum1.Location = new System.Drawing.Point(15, 59);
            this.lblNum1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNum1.Name = "lblNum1";
            this.lblNum1.Size = new System.Drawing.Size(86, 20);
            this.lblNum1.TabIndex = 2;
            this.lblNum1.Text = "1- Number";
            // 
            // lblNum2
            // 
            this.lblNum2.AutoSize = true;
            this.lblNum2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblNum2.Location = new System.Drawing.Point(15, 103);
            this.lblNum2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNum2.Name = "lblNum2";
            this.lblNum2.Size = new System.Drawing.Size(86, 20);
            this.lblNum2.TabIndex = 3;
            this.lblNum2.Text = "2- Number";
            // 
            // iptNum1
            // 
            this.iptNum1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.iptNum1.Location = new System.Drawing.Point(134, 59);
            this.iptNum1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.iptNum1.Name = "iptNum1";
            this.iptNum1.Size = new System.Drawing.Size(155, 26);
            this.iptNum1.TabIndex = 4;
            // 
            // iptNum2
            // 
            this.iptNum2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.iptNum2.Location = new System.Drawing.Point(134, 100);
            this.iptNum2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.iptNum2.Name = "iptNum2";
            this.iptNum2.Size = new System.Drawing.Size(155, 26);
            this.iptNum2.TabIndex = 5;
            // 
            // gbOperation
            // 
            this.gbOperation.Controls.Add(this.txtChoose);
            this.gbOperation.Controls.Add(this.rdoDivision);
            this.gbOperation.Controls.Add(this.rdoAddition);
            this.gbOperation.Controls.Add(this.rdoMultiplication);
            this.gbOperation.Controls.Add(this.rdoSubstraction);
            this.gbOperation.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.gbOperation.Location = new System.Drawing.Point(331, 44);
            this.gbOperation.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.gbOperation.Name = "gbOperation";
            this.gbOperation.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.gbOperation.Size = new System.Drawing.Size(198, 280);
            this.gbOperation.TabIndex = 6;
            this.gbOperation.TabStop = false;
            this.gbOperation.Text = "OPERATION";
            // 
            // txtChoose
            // 
            this.txtChoose.AutoSize = true;
            this.txtChoose.Font = new System.Drawing.Font("Sitka Banner", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.txtChoose.ForeColor = System.Drawing.Color.Chartreuse;
            this.txtChoose.Location = new System.Drawing.Point(13, 24);
            this.txtChoose.Name = "txtChoose";
            this.txtChoose.Size = new System.Drawing.Size(162, 26);
            this.txtChoose.TabIndex = 11;
            this.txtChoose.Text = "Choose an operation";
            this.txtChoose.Visible = false;
            // 
            // rdoDivision
            // 
            this.rdoDivision.AutoSize = true;
            this.rdoDivision.Location = new System.Drawing.Point(8, 192);
            this.rdoDivision.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rdoDivision.Name = "rdoDivision";
            this.rdoDivision.Size = new System.Drawing.Size(120, 24);
            this.rdoDivision.TabIndex = 10;
            this.rdoDivision.TabStop = true;
            this.rdoDivision.Text = "Division ( / )";
            this.rdoDivision.UseVisualStyleBackColor = true;
            this.rdoDivision.CheckedChanged += new System.EventHandler(this.rdoDivision_CheckedChanged);
            // 
            // rdoAddition
            // 
            this.rdoAddition.AutoSize = true;
            this.rdoAddition.Location = new System.Drawing.Point(8, 59);
            this.rdoAddition.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rdoAddition.Name = "rdoAddition";
            this.rdoAddition.Size = new System.Drawing.Size(120, 24);
            this.rdoAddition.TabIndex = 7;
            this.rdoAddition.TabStop = true;
            this.rdoAddition.Text = "Addition (+)";
            this.rdoAddition.UseVisualStyleBackColor = true;
            this.rdoAddition.CheckedChanged += new System.EventHandler(this.rdoAddition_CheckedChanged);
            // 
            // rdoMultiplication
            // 
            this.rdoMultiplication.AutoSize = true;
            this.rdoMultiplication.Location = new System.Drawing.Point(8, 144);
            this.rdoMultiplication.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rdoMultiplication.Name = "rdoMultiplication";
            this.rdoMultiplication.Size = new System.Drawing.Size(155, 24);
            this.rdoMultiplication.TabIndex = 9;
            this.rdoMultiplication.TabStop = true;
            this.rdoMultiplication.Text = "Multiplication (*)";
            this.rdoMultiplication.UseVisualStyleBackColor = true;
            this.rdoMultiplication.CheckedChanged += new System.EventHandler(this.rdoMultiplication_CheckedChanged);
            // 
            // rdoSubstraction
            // 
            this.rdoSubstraction.AutoSize = true;
            this.rdoSubstraction.Location = new System.Drawing.Point(8, 101);
            this.rdoSubstraction.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rdoSubstraction.Name = "rdoSubstraction";
            this.rdoSubstraction.Size = new System.Drawing.Size(142, 24);
            this.rdoSubstraction.TabIndex = 8;
            this.rdoSubstraction.TabStop = true;
            this.rdoSubstraction.Text = "Substraction (-)";
            this.rdoSubstraction.UseVisualStyleBackColor = true;
            this.rdoSubstraction.CheckedChanged += new System.EventHandler(this.rdoSubstraction_CheckedChanged);
            // 
            // btnCalculate
            // 
            this.btnCalculate.BackColor = System.Drawing.Color.SandyBrown;
            this.btnCalculate.Enabled = false;
            this.btnCalculate.Location = new System.Drawing.Point(139, 145);
            this.btnCalculate.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(151, 35);
            this.btnCalculate.TabIndex = 7;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = false;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblResult.Location = new System.Drawing.Point(15, 227);
            this.lblResult.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(53, 20);
            this.lblResult.TabIndex = 8;
            this.lblResult.Text = "Result";
            // 
            // iptResult
            // 
            this.iptResult.Enabled = false;
            this.iptResult.Location = new System.Drawing.Point(116, 224);
            this.iptResult.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.iptResult.Name = "iptResult";
            this.iptResult.Size = new System.Drawing.Size(174, 26);
            this.iptResult.TabIndex = 9;
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.SandyBrown;
            this.btnClear.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnClear.Location = new System.Drawing.Point(110, 289);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(96, 35);
            this.btnClear.TabIndex = 10;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.SandyBrown;
            this.btnExit.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnExit.Location = new System.Drawing.Point(214, 289);
            this.btnExit.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(91, 35);
            this.btnExit.TabIndex = 11;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // timer
            // 
            this.timer.Interval = 1000;
            // 
            // frmCalc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.RosyBrown;
            this.ClientSize = new System.Drawing.Size(544, 373);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.iptResult);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.gbOperation);
            this.Controls.Add(this.iptNum2);
            this.Controls.Add(this.iptNum1);
            this.Controls.Add(this.lblNum2);
            this.Controls.Add(this.lblNum1);
            this.Controls.Add(this.menuStrip);
            this.Font = new System.Drawing.Font("Showcard Gothic", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MainMenuStrip = this.menuStrip;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "frmCalc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Simple Calculator";
            this.Load += new System.EventHandler(this.frmCalc_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.gbOperation.ResumeLayout(false);
            this.gbOperation.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MenuStrip menuStrip;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem mnuClearBtn;
        private ToolStripMenuItem mnuExitBtn;
        private Label lblNum1;
        private Label lblNum2;
        private TextBox iptNum1;
        private TextBox iptNum2;
        private GroupBox gbOperation;
        private RadioButton rdoAddition;
        private RadioButton rdoSubstraction;
        private RadioButton rdoMultiplication;
        private RadioButton rdoDivision;
        private Button btnCalculate;
        private Label lblResult;
        private TextBox iptResult;
        private ToolStripMenuItem mnuChosseColorbtn;
        private ToolStripMenuItem chooseAColorToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem;
        private ToolStripMenuItem aboutToolStripMenuItem;
        private ToolStripMenuItem foreColorToolStripMenuItem;
        private Button btnClear;
        private Button btnExit;
        private ProgressBar progressBar;
        private ToolStripMenuItem changeTextFontToolStripMenuItem;
        private System.Windows.Forms.Timer timer;
        private Label txtChoose;
    }
}